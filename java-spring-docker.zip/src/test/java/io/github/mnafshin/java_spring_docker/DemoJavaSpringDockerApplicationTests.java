package io.github.mnafshin.java_spring_docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJavaSpringDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
